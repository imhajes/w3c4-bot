heroku create saudi34
heroku git:remote -a saudi34
git push heroku master
heroku scale web=0
heroku scale bot=1
heroku create saudi344
heroku git:remote -a saudi344
git push heroku master
heroku scale web=0
heroku scale bot=1
heroku create kuwaiti3445
heroku git:remote -a kuwaiti3445
git push heroku master
heroku scale web=0
heroku scale bot=1
heroku create omani34
heroku git:remote -a omani34
git push heroku master
heroku scale web=0
heroku scale bot=1
heroku create uae4432
heroku git:remote -a uae4432
git push heroku master
heroku scale web=0
heroku scale bot=1
